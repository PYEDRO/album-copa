/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export enum Rarity {
  COMMON = 'common',
  RARE = 'rare',
  LEGENDARY = 'legendary',
}

export interface Attributes {
  agility: number; // Agilidade no Teclado
  defense: number; // Defesa de Bugs
  attack: number;  // Ataque de Criatividade
}

export interface Collaborator {
  id: string;
  name: string;
  role: string;
  team: string;
  rarity: Rarity;
  attributes: Attributes;
  achievements: string[];
  imageUrl: string;
  bio: string;
}

export interface UserStats {
  stickersOwned: string[]; // IDs of collaborators owned
  duplicates: Record<string, number>;
  packetsOpened: number;
  guessesRight: number;
  guessesTotal: number;
  lastGuessDate: string | null;
  lastPackDate: string | null;
}
