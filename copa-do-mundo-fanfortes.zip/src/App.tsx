import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Book, 
  Gamepad2, 
  Package, 
  Search, 
  Trophy, 
  ChevronRight, 
  ChevronLeft,
  Sparkles,
  Zap,
  Shield,
  Sword,
  Users,
  ArrowLeftRight,
  TrendingUp,
  LogOut,
  Flag,
  User,
  Bot,
  Loader2,
  Mail
} from 'lucide-react';
import { COLLABORATORS, INITIAL_USER_STATS, RANKING_DATA } from './constants';
import { Rarity, Collaborator, UserStats } from './types';
import { signInWithGoogle } from './services/firebase';

// --- Components ---

const STICKERS_PER_PAGE = 11;
const TOTAL_PAGES = Math.ceil(COLLABORATORS.length / STICKERS_PER_PAGE);

const RobotMascot = ({ pageIndex, isPageComplete }: { pageIndex: number, isPageComplete?: boolean }) => {
  const phrases = isPageComplete 
    ? ["Uau! Time completo!", "Que coleção incrível!", "Você é fera!", "Álbum de mestre!"]
    : [
    "Boa sorte no pack!",
    "Quase completando!",
    "Que figurinha top!",
    "Falta pouco agora!",
    "Rumo ao troféu!",
    "Show de bola!",
    "Incrível esse!",
    "Bora colecionar!"
  ];
  const phrase = phrases[pageIndex % phrases.length];

  return (
    <motion.div 
      initial={{ scale: 0, opacity: 0, x: 20 }}
      animate={{ scale: 1, opacity: 1, x: 0 }}
      whileHover={{ y: -8, scale: 1.1, rotate: 2 }}
      className="absolute -bottom-6 -right-6 z-30 hidden sm:block cursor-help drop-shadow-2xl"
    >
      <div className="relative">
        {/* Speech Bubble */}
        <motion.div 
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 1, duration: 0.5 }}
          className="absolute -top-12 -left-20 bg-white text-slate-900 px-3 py-1.5 rounded-2xl rounded-br-none text-[8px] font-black uppercase shadow-2xl border-2 border-red-500/20 whitespace-nowrap z-40 transform -rotate-3"
        >
          <div className="flex items-center gap-2">
            <span className="text-red-600">{phrase}</span>
            <div className="w-1 h-1 bg-emerald-500 rounded-full animate-ping" />
          </div>
          <div className="absolute bottom-[-8px] right-2 w-0 h-0 border-l-[8px] border-l-transparent border-t-[8px] border-t-white" />
        </motion.div>

        {/* Mascot SVG */}
        <svg width="100" height="100" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="25" y="15" width="50" height="35" rx="12" fill="#F1F5F9" stroke="#94A3B8" strokeWidth="2" />
          <rect x="30" y="20" width="40" height="20" rx="6" fill="#1E293B" />
          <circle cx="40" cy="28" r="2" fill="#60A5FA" />
          <circle cx="60" cy="28" r="2" fill="#60A5FA" />
          <path d="M45 35 Q50 38 55 35" stroke="#60A5FA" strokeWidth="1.5" strokeLinecap="round" />
          <path d="M30 50 L70 50 L75 75 L25 75 Z" fill="#DC2626" stroke="#991B1B" strokeWidth="2" />
          <text x="50" y="68" textAnchor="middle" fill="white" fontSize="12" fontWeight="900" style={{ fontStyle: 'italic' }}>F</text>
          <motion.g
            animate={{ rotate: [0, -30, 0] }}
            transition={{ repeat: Infinity, duration: 1.5, ease: "easeInOut" }}
            style={{ transformOrigin: "30px 55px" }}
          >
            <path d="M30 55 L15 40" stroke="#94A3B8" strokeWidth="5" strokeLinecap="round" />
            <circle cx="15" cy="40" r="4" fill="#F1F5F9" stroke="#94A3B8" strokeWidth="1.5" />
          </motion.g>
          <path d="M70 55 L82 62" stroke="#94A3B8" strokeWidth="5" strokeLinecap="round" />
          <g transform="translate(85, 70) scale(0.8)">
            <circle r="10" fill="white" stroke="#64748B" strokeWidth="1" />
            <circle r="3" fill="#1E293B" />
          </g>
          <rect x="35" y="75" width="8" height="12" fill="#F1F5F9" stroke="#94A3B8" strokeWidth="1.5" />
          <rect x="57" y="75" width="8" height="12" fill="#F1F5F9" stroke="#94A3B8" strokeWidth="1.5" />
          <rect x="32" y="85" width="12" height="5" rx="2.5" fill="#DC2626" />
          <rect x="56" y="85" width="12" height="5" rx="2.5" fill="#DC2626" />
        </svg>
      </div>
    </motion.div>
  );
};

const StatBar = ({ label, value, icon: Icon, color, description }: { label: string, value: number, icon: any, color: string, description?: string }) => (
  <div className="flex flex-col gap-1 w-full group/stat relative">
    {description && (
      <div className="absolute bottom-full left-0 mb-2 w-48 p-2 bg-slate-900 text-white text-[9px] font-medium rounded-lg opacity-0 group-hover/stat:opacity-100 transition-opacity pointer-events-none z-50 shadow-xl border border-slate-700 leading-tight">
        {description}
        <div className="absolute top-full left-4 -mt-1 border-4 border-transparent border-t-slate-900" />
      </div>
    )}
    <div className="flex justify-between text-[10px] uppercase font-black tracking-widest opacity-80">
      <div className="flex items-center gap-1">
        <Icon size={10} className={color} />
        {label}
      </div>
      <span>{value}%</span>
    </div>
    <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden border border-slate-200 shadow-inner">
      <motion.div 
        initial={{ width: 0 }}
        animate={{ width: `${value}%` }}
        className={`h-full ${color.replace('text-', 'bg-')} shadow-[0_0_8px_rgba(255,255,255,1)]`} 
      />
    </div>
  </div>
);

const StickerCard = ({ 
  collaborator, 
  isCollected = true, 
  onClick 
}: { 
  collaborator: Collaborator; 
  isCollected?: boolean;
  onClick?: () => void;
  key?: any;
}) => {
  const isRare = collaborator.rarity === Rarity.RARE;
  const isLegendary = collaborator.rarity === Rarity.LEGENDARY;

  if (!isCollected) {
    return (
      <div className="flex flex-col gap-1.5 group">
        <div 
          className="w-full aspect-[4/5] bg-slate-100 border-2 border-slate-200 rounded-lg flex items-center justify-center relative group transition-all shadow-inner overflow-hidden"
          id={`slot-${collaborator.id}`}
        >
          <div className="absolute inset-0 opacity-5 bg-[radial-gradient(#000_1px,transparent_1px)] bg-[size:8px_8px]" />
          <div className="absolute inset-1.5 border border-dashed border-slate-300 rounded flex flex-col items-center justify-center">
            <span className="text-xl font-black text-slate-200 italic tracking-tighter">#{collaborator.id}</span>
          </div>
        </div>
        <div className="h-1.5 bg-slate-100/50 w-1/2 mx-auto rounded-full" />
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-1 group">
      <motion.div
        layoutId={`card-${collaborator.id}`}
        whileHover={{ scale: 1.05, y: -3 }}
        whileTap={{ scale: 0.95 }}
        onClick={onClick}
        className={`relative w-full aspect-[4/5] rounded-lg overflow-hidden shadow-lg cursor-pointer transition-all duration-300 ${
          isLegendary ? 'bg-holographic' : isRare ? 'bg-gold-shiny animate-gold-glow' : 'bg-white'
        } border-2 ${
          isLegendary ? 'border-red-400' : isRare ? 'border-amber-300' : 'border-red-100'
        } ${isRare || isLegendary ? 'panini-shadow' : ''}`}
        id={`card-container-${collaborator.id}`}
      >
        {(isRare || isLegendary) && <div className="absolute inset-0 shiny-overlay opacity-30 z-20 pointer-events-none" />}
        
        <div className={`absolute inset-0.5 rounded-md overflow-hidden flex flex-col p-1 ${
          isLegendary ? 'bg-white/90 backdrop-blur-sm' : isRare ? 'bg-gradient-to-b from-amber-50 to-white' : 'bg-white'
        }`}>
          <div className="flex justify-between items-center mb-0.5 px-0.5">
             <span className={`text-[4px] font-black uppercase tracking-widest leading-none ${isRare ? 'text-amber-800' : 'text-slate-400'}`}>{collaborator.team.split(' ')[0]}</span>
             <span className={`text-[5px] font-black ${isRare ? 'text-amber-600' : 'text-red-500'}`}>#{collaborator.id}</span>
          </div>

          <div className={`relative h-[55%] rounded sm border overflow-hidden mb-1 ${isRare ? 'border-amber-200 bg-amber-50' : 'border-slate-50 bg-slate-50'}`}>
            <img 
              src={collaborator.imageUrl} 
              alt={collaborator.name} 
              className="w-full h-full object-cover" 
              referrerPolicy="no-referrer"
            />
          </div>

          <div className="flex flex-col gap-0 mb-0.5 min-h-0">
            <h3 className={`text-[7px] font-black uppercase tracking-tighter truncate leading-tight ${isRare ? 'text-amber-900' : 'text-slate-800'}`}>
              {collaborator.name}
            </h3>
            <p className={`text-[5px] font-bold uppercase leading-none truncate ${isRare ? 'text-amber-600' : 'text-slate-300'}`}>
              {collaborator.role}
            </p>
          </div>

          <div className="mt-auto pt-0.5 border-t border-slate-100/10">
            <div className="flex justify-between items-center text-[4px] uppercase font-black">
              <span className={isRare ? 'text-amber-600' : 'text-slate-300'}>PWR</span>
              <div className="flex gap-0.5">
                {[1, 2, 3].map((i) => (
                  <div 
                    key={i} 
                    className={`w-0.5 h-0.5 rounded-full ${
                      i <= Math.round((collaborator.attributes.agility + collaborator.attributes.defense + collaborator.attributes.attack) / 80) 
                      ? (isRare ? 'bg-amber-500 shadow-[0_0_2px_#f59e0b]' : 'bg-red-500') 
                      : (isRare ? 'bg-amber-100' : 'bg-slate-100')
                    }`} 
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </motion.div>
      <div className="text-center px-0.5">
        <p className="text-[7px] font-black uppercase italic tracking-tighter text-slate-800 group-hover:text-red-600 transition-colors truncate">
          {collaborator.name}
        </p>
      </div>
    </div>
  );
};

const AlbumPage = ({ 
  pageIndex, 
  ownedStickers, 
  onStickerClick,
  direction = 0
}: { 
  pageIndex: number; 
  ownedStickers: string[]; 
  onStickerClick: (c: Collaborator) => void;
  direction?: number;
  key?: any;
}) => {
  const startIdx = pageIndex * STICKERS_PER_PAGE;
  const endIdx = startIdx + STICKERS_PER_PAGE;
  const pageStickers = COLLABORATORS.slice(startIdx, endIdx);
  const teamName = pageStickers[0]?.team || 'Seleção';
  const isPageComplete = pageStickers.length > 0 && pageStickers.every(s => ownedStickers.includes(s.id));

  return (
    <motion.div 
      key={pageIndex}
      initial={{ 
        opacity: 0,
        x: direction > 0 ? 100 : -100,
        rotateY: direction > 0 ? 45 : -45,
        scale: 0.95
      }}
      animate={{ 
        opacity: 1, 
        x: 0,
        rotateY: 0,
        scale: 1,
        transition: { 
          type: "spring",
          stiffness: 40,
          damping: 20,
          mass: 1.5,
          duration: 1.2
        }
      }}
      exit={{ 
        opacity: 0,
        x: direction > 0 ? -100 : 100,
        rotateY: direction > 0 ? -45 : 45,
        scale: 0.95,
        transition: { duration: 0.8, ease: "easeInOut" }
      }}
      style={{ 
        perspective: 1200,
        transformOrigin: direction > 0 ? "left center" : "right center"
      }}
      className="relative bg-white min-h-[480px] md:min-h-[580px] h-full p-4 md:p-6 pt-10 overflow-visible flex flex-col w-full shadow-2xl transition-shadow duration-500 hover:shadow-red-900/10 rounded-[32px] border-2 border-slate-200 mx-auto max-w-2xl"
    >
      {/* Page Shine Effect */}
      <motion.div 
        initial={{ opacity: 0, x: '-100%' }}
        animate={{ x: '200%', opacity: [0, 0.2, 0] }}
        transition={{ duration: 1.5, ease: "easeInOut" }}
        className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent pointer-events-none z-50 transform skew-x-12"
      />
      {/* Background Pattern */}
      <div className="absolute inset-0 album-bg-pattern pointer-events-none opacity-20" />
      
      <div className="curled-corner scale-50 origin-top-right opacity-30" />

      <div className="relative z-10 flex flex-col h-full space-y-4">
        <div className="flex flex-col md:flex-row items-center justify-between border-b-2 border-red-600/30 pb-2 gap-2">
          <div className="flex items-center gap-2 w-full md:w-auto">
            <div className="relative flex-shrink-0">
              <div className="w-9 h-9 md:w-10 md:h-10 bg-red-600 rounded-lg flex items-center justify-center text-white font-black text-base md:text-lg shadow-lg border-2 border-red-800 rotate-3 z-10 relative">
                {pageIndex + 1}
              </div>
            </div>
            <div className="space-y-0 min-w-0 flex-1">
              <div className="flex items-center gap-1">
                <Flag size={8} className={isPageComplete ? "text-amber-500 fill-amber-500" : "text-red-500 fill-red-500"} />
                <span className="text-[7px] font-black uppercase text-slate-400 tracking-widest">Grupo {String.fromCharCode(65 + pageIndex)}</span>
                {isPageComplete && (
                  <motion.span 
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="ml-2 text-[6px] bg-amber-500 text-white px-1 py-0.5 rounded-full font-black uppercase tracking-tighter"
                  >
                    Time Completo!
                  </motion.span>
                )}
              </div>
              <h2 className="text-base md:text-lg lg:text-xl font-black italic uppercase tracking-tighter text-slate-900 leading-tight truncate">{teamName}</h2>
              <div className="flex gap-1">
                 <span className="text-[5px] bg-red-600 text-white px-1 py-0.5 rounded font-black uppercase shadow-sm">Oficial</span>
                 <div className="flex items-center gap-0.5 bg-emerald-600 text-white px-1 py-0.5 rounded font-black uppercase shadow-sm">
                    <User size={5} className="text-white" />
                    <span className="text-[5px]">Fanfortes 2026</span>
                 </div>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-2 bg-white/60 backdrop-blur-md p-1 rounded-lg border border-slate-100 flex-shrink-0 shadow-sm">
             <div className="text-center px-1">
                <div className="text-[6px] font-black text-slate-400 uppercase leading-none">Match</div>
                <div className="text-xs font-black text-red-600 italic leading-none">SET 05</div>
             </div>
             <div className="h-4 w-px bg-slate-200" />
             <div className="text-center px-1">
                <div className="text-[6px] font-black text-slate-400 uppercase leading-none">Stats</div>
                <div className="text-xs font-black text-slate-800 leading-none">
                  {Math.round((pageStickers.filter(c => ownedStickers.includes(c.id)).length / STICKERS_PER_PAGE) * 100)}%
                </div>
             </div>
          </div>
        </div>

        <div className="grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-3 gap-2 md:gap-3 overflow-visible relative">
          {pageStickers.map(c => (
            <StickerCard 
              key={c.id} 
              collaborator={c} 
              isCollected={ownedStickers.includes(c.id)} 
              onClick={() => onStickerClick(c)}
            />
          ))}
          {pageStickers.length <= STICKERS_PER_PAGE && (
            <div className="w-full aspect-[4/5] bg-slate-50 border border-slate-200 rounded-lg flex items-center justify-center flex-col p-1 text-center border-dashed opacity-40">
              <Trophy className="text-slate-300 mb-1" size={16} />
              <span className="text-[6px] font-black uppercase text-slate-400 tracking-tighter">Prêmio</span>
            </div>
          )}
        </div>
        
        <RobotMascot pageIndex={pageIndex} isPageComplete={isPageComplete} />
      </div>
    </motion.div>
  );
};

// --- Ranking Component ---

const RankingSection = ({ currentOwned }: { currentOwned: number }) => {
  const allRankings = [
    { name: 'Você (thalia)', score: currentOwned, photo: 'https://api.dicebear.com/7.x/avataaars/svg?seed=thalia', isUser: true },
    ...RANKING_DATA
  ].sort((a, b) => b.score - a.score);

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-3xl mx-auto space-y-8"
    >
      <div className="text-center space-y-2">
        <h2 className="text-4xl font-black italic uppercase italic text-red-600 tracking-tighter">Ranking de Colecionadores</h2>
        <p className="text-slate-400 font-medium">Quem está mais perto de completar o álbum Fanfortes?</p>
      </div>

      <div className="bg-slate-50 rounded-[40px] border-4 border-red-100 p-8 shadow-inner">
        <div className="space-y-4">
          {allRankings.map((user, i) => (
            <div 
              key={user.name}
              className={`flex items-center justify-between p-4 rounded-2xl transition-all ${
                user.isUser ? 'bg-red-600 text-white shadow-xl scale-105' : 'bg-white border border-slate-100'
              }`}
            >
              <div className="flex items-center gap-6">
                <span className={`text-xl font-black italic w-8 ${user.isUser ? 'text-white' : 'text-red-600'}`}>#{i + 1}</span>
                <img src={user.photo} alt={user.name} className="w-12 h-12 rounded-full border-2 border-slate-200 bg-slate-50" />
                <span className={`font-black uppercase tracking-tighter ${user.isUser ? 'text-white' : 'text-slate-800'}`}>{user.name}</span>
              </div>
              <div className="flex flex-col items-end">
                <span className={`text-xl font-black ${user.isUser ? 'text-white' : 'text-red-600'}`}>{user.score}</span>
                <span className={`text-[8px] font-black uppercase tracking-widest ${user.isUser ? 'text-red-200' : 'text-slate-400'}`}>FIGURINHAS</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </motion.div>
  );
};

// --- Trading Component ---

const TradingSection = ({ stats, onTrade }: { stats: UserStats, onTrade: (id: string) => void }) => {
  const [isAnimating, setIsAnimating] = useState(false);
  const duplicateIds = Object.keys(stats.duplicates).filter(id => stats.duplicates[id] > 0);
  const totalDuplicates: number = Object.values(stats.duplicates).reduce((a, b) => (a as number) + (b as number), 0) as number;
  
  const handleStartTrade = () => {
    setIsAnimating(true);
    setTimeout(() => {
      onTrade('any');
      setIsAnimating(false);
    }, 2000);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-5xl mx-auto space-y-12"
    >
      <div className="text-center space-y-3">
        <div className="w-16 h-16 bg-red-100 rounded-2xl flex items-center justify-center mx-auto mb-4 rotate-12">
          <ArrowLeftRight className="text-red-600" size={32} />
        </div>
        <h2 className="text-4xl font-black italic uppercase text-red-600 tracking-tighter">Banca de Trocas</h2>
        <p className="text-slate-500 font-medium">Troque 3 figurinhas repetidas por uma figurinha aleatória que você não tem!</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        {/* Duplicates Sidebar */}
        <div className="bg-slate-50 rounded-[40px] border-4 border-red-50 p-8 shadow-inner space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-black uppercase italic text-slate-800">Suas Repetidas</h3>
            <span className="bg-red-100 text-red-600 px-3 py-1 rounded-full text-xs font-black">
              Total: {totalDuplicates}
            </span>
          </div>

          <div className="grid grid-cols-3 gap-4">
            {duplicateIds.length === 0 ? (
              <div className="col-span-3 py-12 text-center space-y-2 opacity-50">
                <Package className="mx-auto text-slate-300" size={32} />
                <p className="text-[10px] font-black uppercase text-slate-400">Nenhuma repetida ainda</p>
              </div>
            ) : (
              duplicateIds.map(id => {
                const c = COLLABORATORS.find(col => col.id === id);
                if (!c) return null;
                return (
                  <motion.div 
                    key={id} 
                    className="relative group"
                    whileHover={{ scale: 1.05 }}
                  >
                    <div className="aspect-[3/4] rounded-xl overflow-hidden border-2 border-red-100 bg-white">
                      <img src={c.imageUrl} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                    </div>
                    <div className="absolute -top-2 -right-2 bg-red-600 text-white w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-black border-2 border-white shadow-lg">
                      x{stats.duplicates[id]}
                    </div>
                  </motion.div>
                );
              })
            )}
          </div>
        </div>

        {/* Trade Action */}
        <div className="bg-slate-900 rounded-[40px] p-12 text-white flex flex-col items-center justify-center text-center space-y-8 shadow-2xl relative overflow-hidden">
          {/* Animated Background Gradients */}
          <div className="absolute inset-0 bg-gradient-to-br from-red-900/40 via-transparent to-red-900/40" />
          <motion.div 
            animate={{ 
              scale: [1, 1.2, 1],
              rotate: [0, 90, 180, 270, 360],
              opacity: [0.1, 0.2, 0.1]
            }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full aspect-square bg-red-600 rounded-full blur-[120px]" 
          />
          
          <div className="space-y-6 relative z-10 w-full">
            <div className="relative h-40 flex items-center justify-center gap-4">
              <AnimatePresence>
                {isAnimating ? (
                  <>
                    {[0, 1, 2].map((i) => (
                      <motion.div
                        key={`trade-card-${i}`}
                        initial={{ x: -200, opacity: 0, rotate: -20, scale: 0.5 }}
                        animate={{ 
                          x: 0, 
                          opacity: 1, 
                          rotate: (i - 1) * 15, 
                          scale: 1,
                          transition: { delay: i * 0.2, duration: 0.5 }
                        }}
                        exit={{ 
                          scale: 0, 
                          opacity: 0, 
                          filter: 'blur(20px)',
                          transition: { delay: 1, duration: 0.5 }
                        }}
                        className="w-24 aspect-[3/4] bg-white rounded-lg border-2 border-red-500 shadow-xl overflow-hidden"
                      >
                        <div className="w-full h-full bg-red-50 flex items-center justify-center">
                          <Package className="text-red-200" size={32} />
                        </div>
                      </motion.div>
                    ))}
                    <motion.div
                      initial={{ scale: 0, opacity: 0 }}
                      animate={{ 
                        scale: [0, 1.2, 1], 
                        opacity: 1,
                        transition: { delay: 1.5, duration: 0.5 }
                      }}
                      className="absolute inset-0 flex items-center justify-center"
                    >
                      <div className="w-32 h-32 bg-red-600 rounded-full flex items-center justify-center shadow-[0_0_50px_rgba(239,68,68,0.8)] border-4 border-red-400">
                        <Sparkles className="text-white animate-spin-slow" size={48} />
                      </div>
                    </motion.div>
                  </>
                ) : (
                  <div className="flex flex-col items-center gap-4">
                    <div className="p-8 bg-white/5 rounded-full border-2 border-dashed border-white/20">
                      <Trophy className="opacity-40" size={64} />
                    </div>
                    <div className="flex gap-4 items-center scale-125">
                      <div className="w-10 h-10 rounded-xl border-2 border-white/20 flex items-center justify-center font-black text-white/50">3</div>
                      <ArrowLeftRight className="text-red-500" size={20} />
                      <div className="w-10 h-10 rounded-xl bg-white text-slate-900 flex items-center justify-center font-black text-xl shadow-lg">?</div>
                    </div>
                  </div>
                )}
              </AnimatePresence>
            </div>

            <div className="space-y-4">
              <h3 className="text-3xl font-black italic uppercase tracking-tighter">Troca de Elite</h3>
              <p className="text-slate-400 font-medium text-sm max-w-xs mx-auto">Sacrifique 3 talentos repetidos para desbloquear um perfil inédito em sua rede.</p>
            </div>

            <button 
              disabled={totalDuplicates < 3 || isAnimating}
              onClick={handleStartTrade}
              className="w-full bg-red-600 text-white hover:bg-red-500 py-6 rounded-[24px] font-black italic uppercase tracking-widest transition-all shadow-xl disabled:opacity-20 disabled:cursor-not-allowed group border-2 border-red-700 relative overflow-hidden"
            >
              <span className="relative z-10 flex items-center justify-center gap-3">
                {isAnimating ? 'PROCESSANDO TROCA...' : 'INICIAR PROTOCOLO DE TROCA'}
                {!isAnimating && <ChevronRight className="group-hover:translate-x-1 transition-transform" size={20} />}
              </span>
              {isAnimating && (
                <motion.div 
                  initial={{ x: '-100%' }}
                  animate={{ x: '100%' }}
                  transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                  className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent"
                />
              )}
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
};


const LoginScreen = ({ onLogin }: { onLogin: (email: string) => void }) => {
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.toLowerCase().endsWith('@fortestecnologia.com.br')) {
      setError('Por favor, utilize seu e-mail corporativo (@fortestecnologia.com.br)');
      return;
    }
    setError('');
    onLogin(email);
  };

  return (
    <div className="min-h-screen bg-red-600 flex items-center justify-center p-6 border-8 border-red-800">
      <div className="absolute inset-0 opacity-10 pointer-events-none album-bg-pattern" />
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="bg-white rounded-[40px] p-8 md:p-12 shadow-2xl max-w-md w-full border-4 border-slate-100 flex flex-col items-center text-center space-y-8 relative z-10"
      >
        <motion.div 
          animate={{ rotate: [0, 10, -10, 0] }}
          transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
          className="w-20 h-20 bg-red-600 rounded-full flex items-center justify-center shadow-xl border-4 border-red-800"
        >
          <span className="text-white font-black text-4xl italic">F</span>
        </motion.div>
        
        <div className="space-y-2">
          <h1 className="text-3xl font-black italic uppercase text-red-600 tracking-tighter">Fanfortes 2026</h1>
          <p className="text-slate-400 font-bold uppercase text-[10px] tracking-widest leading-tight">Copa do Mundo de Conquistas & Talentos</p>
        </div>

        <form 
          onSubmit={handleSubmit}
          className="w-full space-y-4"
        >
          <div className="text-left space-y-1.5">
            <label className="text-[10px] font-black uppercase text-slate-400 ml-1">E-mail Corporativo</label>
            <input 
              type="email" 
              placeholder="seu.nome@fortestecnologia.com.br"
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                if (error) setError('');
              }}
              className={`w-full px-5 py-4 bg-slate-50 border-2 rounded-2xl focus:outline-none font-medium transition-all ${
                error ? 'border-red-300 bg-red-50' : 'border-slate-100 focus:border-red-600'
              }`}
              required
            />
            {error && (
              <motion.p 
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-[10px] text-red-600 font-bold px-1"
              >
                {error}
              </motion.p>
            )}
          </div>
          
          <button 
            type="submit"
            className="w-full bg-red-600 text-white font-black italic uppercase tracking-widest py-5 rounded-2xl hover:bg-red-700 transition-all shadow-lg active:scale-95 flex items-center justify-center gap-2"
          >
            ENTRAR NO ÁLBUM <ChevronRight size={20} />
          </button>
        </form>

        <p className="text-slate-300 text-[10px] font-medium leading-relaxed">
          Uso exclusivo para colaboradores da Fortes Tecnologia.<br/>
          Sua jornada de reconhecimento começa aqui.
        </p>
      </motion.div>
    </div>
  );
};


const GeometricBackground = () => {
  const shapesColors = [
    'text-red-500', 'text-orange-500', 'text-yellow-400', 
    'text-emerald-500', 'text-blue-500', 'text-purple-600',
    'text-pink-500', 'text-red-600', 'text-blue-700'
  ];

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {/* Left Column of Shapes */}
      <div className="absolute top-0 left-0 bottom-0 w-24 md:w-32 flex flex-col justify-around py-4 z-0">
        {shapesColors.map((color, i) => (
          <motion.div
            key={`left-${i}`}
            initial={{ x: -100, opacity: 0 }}
            animate={{ x: -20, opacity: 0.8 }}
            transition={{ delay: i * 0.1, duration: 0.8 }}
            className={`w-32 h-32 ${color}`}
          >
            <svg viewBox="0 0 100 100" className="w-full h-full fill-current">
              <path d="M 100,0 A 100,100 0 0,0 100,100 L 100,50 A 50,50 0 0,1 100,0 Z" />
            </svg>
          </motion.div>
        ))}
      </div>

      {/* Right Column of Shapes */}
      <div className="absolute top-0 right-0 bottom-0 w-24 md:w-32 flex flex-col justify-around py-4 z-0">
        {[...shapesColors].reverse().map((color, i) => (
          <motion.div
            key={`right-${i}`}
            initial={{ x: 100, opacity: 0 }}
            animate={{ x: 20, opacity: 0.8 }}
            transition={{ delay: i * 0.1, duration: 0.8 }}
            className={`w-32 h-32 ${color} transform rotate-180`}
          >
            <svg viewBox="0 0 100 100" className="w-full h-full fill-current">
              <path d="M 100,0 A 100,100 0 0,0 100,100 L 100,50 A 50,50 0 0,1 100,0 Z" />
            </svg>
          </motion.div>
        ))}
      </div>

      {/* Floating Circles in the background */}
      <div className="absolute inset-0 opacity-10">
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={`circle-${i}`}
            animate={{ 
              y: [0, -20, 0],
              x: [0, 10, 0],
              scale: [1, 1.1, 1]
            }}
            transition={{ 
              duration: 3 + i, 
              repeat: Infinity, 
              ease: "easeInOut",
              delay: i * 0.5
            }}
            className="absolute rounded-full border-4 border-white/20"
            style={{
              width: `${100 + i * 50}px`,
              height: `${100 + i * 50}px`,
              top: `${10 + i * 15}%`,
              left: `${20 + (i % 3) * 20}%`
            }}
          />
        ))}
      </div>

      <div className="absolute inset-0 bg-slate-900/10 backdrop-blur-[2px]" />
    </div>
  );
};

const AlbumCover = ({ onLogin }: { onLogin: (email: string) => void }) => {
  const [isLoading, setIsLoading] = useState(false);

  const handleGoogleLogin = async () => {
    setIsLoading(true);
    try {
      const result: any = await signInWithGoogle();
      if (result.user) {
        onLogin(result.user.email);
      }
    } catch (error) {
      console.error(error);
      alert('Erro ao vincular Gmail. Tente novamente.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4 overflow-hidden relative">
      <GeometricBackground />
      
      {/* Background Overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-red-600/5 via-transparent to-blue-600/5 pointer-events-none" />

      <motion.div 
        initial={{ y: 50, opacity: 0, scale: 0.9 }}
        animate={{ y: 0, opacity: 1, scale: 1 }}
        className="relative z-10 w-full max-w-[340px] md:max-w-md bg-white rounded-[32px] md:rounded-[40px] shadow-[0_20px_80px_rgba(0,0,0,0.15)] border-[6px] md:border-[12px] border-slate-100 flex flex-col p-4 md:p-10 text-center overflow-hidden max-h-[92vh] md:max-h-[98vh] my-auto"
      >
        {/* Page Shine */}
        <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-red-500 via-emerald-500 via-blue-500 via-yellow-500 to-red-500" />
        
        {/* Top Header Labels */}
        <div className="flex justify-between items-start mb-1 md:mb-4">
           <div className="text-left">
             <p className="text-[7px] font-black uppercase text-slate-300 tracking-tighter leading-none">Official Sticker</p>
             <p className="text-[9px] md:text-[12px] font-black uppercase text-slate-900 tracking-tighter">Collection</p>
           </div>
           <motion.div 
             animate={{ rotate: 360 }}
             transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
             className="w-8 h-8 md:w-12 md:h-12 bg-red-600 rounded-full flex items-center justify-center text-white font-black italic text-base border-2 md:border-4 border-white shadow-lg"
           >
             F
           </motion.div>
        </div>

        {/* Central Shield Shield */}
        <div className="flex-1 flex flex-col items-center justify-center space-y-1 md:space-y-3">
          <motion.div 
             whileHover={{ scale: 1.05, rotate: 1 }}
             className="relative"
          >
            {/* Massive Glow */}
            <div className="absolute inset-0 bg-yellow-400 blur-[40px] md:blur-[60px] opacity-20 animate-pulse" />
            
            <div className="w-32 md:w-64 aspect-[4/5] bg-gradient-to-b from-white to-slate-50 rounded-t-[45%] rounded-b-[15%] shadow-[0_10px_30px_rgba(0,0,0,0.1)] border-[2px] md:border-[3px] border-slate-200 flex flex-col items-center justify-center p-2 md:p-6 relative overflow-hidden">
               {/* Background Text */}
               <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-900/5 font-black italic text-[24px] md:text-[60px] leading-tight pointer-events-none text-center">
                  <div>COPA</div>
                  <div>FANFORTES</div>
               </div>

               {/* Trophy Container */}
               <div className="w-12 h-12 md:w-24 md:h-24 flex items-center justify-center mb-0.5 md:mb-1 relative z-10">
                  <motion.div
                    animate={{ 
                      y: [0, -4, 0],
                      scale: [1, 1.05, 1]
                    }}
                    transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                  >
                    <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-10 h-10 md:w-20 md:h-20">
                      <defs>
                        <linearGradient id="gold-cover" x1="0%" y1="0%" x2="100%" y2="100%">
                          <stop offset="0%" stopColor="#FDE68A" />
                          <stop offset="50%" stopColor="#F59E0B" />
                          <stop offset="100%" stopColor="#B45309" />
                        </linearGradient>
                      </defs>
                      <path d="M6 9V2h12v7c0 3.31-2.69 6-6 6s-6-2.69-6-6Z" fill="url(#gold-cover)" />
                      <path d="M12 15v5m-4 0h8m-11-9h3m8 0h3" stroke="url(#gold-cover)" strokeWidth="1.5" strokeLinecap="round" />
                      <path d="M4 5a2 2 0 0 1 2-2h0m12 0h0a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2h-2m-10 0H4a2 2 0 0 1-2-2V5" stroke="url(#gold-cover)" strokeWidth="1.5" strokeLinecap="round" />
                    </svg>
                  </motion.div>
               </div>
               
               <div className="text-center relative z-10">
                 <p className="text-slate-500 font-black italic text-[8px] md:text-sm uppercase tracking-widest leading-none mb-1">COPA</p>
                 <h2 className="text-red-600 font-black italic text-base md:text-4xl tracking-tighter uppercase leading-none">FANFORTES</h2>
               </div>
               <div className="h-0.5 w-6 md:h-1.5 md:w-16 bg-slate-900 my-1 md:my-2 rounded-full relative z-10" />
               <p className="text-slate-900 font-black text-xs md:text-2xl tracking-widest uppercase relative z-10">FIFA</p>
            </div>
          </motion.div>

          <div className="space-y-0 text-slate-900 flex flex-col items-center">
            <h1 className="text-lg md:text-5xl font-black italic uppercase tracking-tighter leading-tight">WORLD CUP</h1>
            <p className="text-red-600 font-black italic text-2xl md:text-6xl tracking-tighter -mt-1">2026</p>
          </div>
        </div>

        {/* Action Button */}
        <div className="mt-2 md:mt-6 space-y-2 mb-2 md:mb-0">
           <button 
             onClick={handleGoogleLogin}
             disabled={isLoading}
             className={`w-full font-black italic uppercase tracking-widest py-3 md:py-6 rounded-[16px] md:rounded-[28px] transition-all shadow-xl active:scale-95 group flex flex-col items-center justify-center gap-0 relative overflow-hidden ${
               isLoading ? 'bg-slate-400 cursor-not-allowed' : 'bg-slate-900 hover:bg-emerald-600 text-white'
             }`}
           >
             <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
             <span className="flex items-center gap-3 text-sm md:text-lg">
                {isLoading ? (
                  <>
                    <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1, ease: 'linear' }}>
                      <Loader2 className="w-5 h-5" />
                    </motion.div>
                    VINCULANDO...
                  </>
                ) : (
                  <>
                    <Mail className="w-5 h-5 opacity-70" />
                    ABRIR ÁLBUM 
                    <ChevronRight className="w-4 h-4 md:w-6 md:h-6 group-hover:translate-x-1 transition-transform" />
                  </>
                )}
             </span>
             <span className="text-[8px] md:text-[10px] opacity-60 font-bold tracking-widest uppercase">CONECTAR COM @GMAIL.COM</span>
           </button>
        </div>
      </motion.div>
    </div>
  );
};



// --- Main App ---

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(() => {
    return typeof window !== 'undefined' ? sessionStorage.getItem('isLoggedIn') === 'true' : false;
  });
  const [userEmail, setUserEmail] = useState(() => {
    return typeof window !== 'undefined' ? sessionStorage.getItem('userEmail') || '' : '';
  });
  const [showCover, setShowCover] = useState(true);
  const [view, setView] = useState<'album' | 'game' | 'opening' | 'ranking' | 'trading'>('album');
  const [currentPage, setCurrentPage] = useState(0);
  const [direction, setDirection] = useState(0);

  const paginate = (newPage: number) => {
    setDirection(newPage > currentPage ? 1 : -1);
    setCurrentPage(newPage);
  };
  const [stats, setStats] = useState<UserStats>(() => {
    const saved = typeof window !== 'undefined' ? localStorage.getItem('album_stats') : null;
    const parsed = saved ? JSON.parse(saved) : INITIAL_USER_STATS;
    // Sanitize: ensure all fields from INITIAL_USER_STATS exist
    return { ...INITIAL_USER_STATS, ...parsed };
  });
  const [activePack, setActivePack] = useState<Collaborator[]>([]);
  const [selectedSticker, setSelectedSticker] = useState<Collaborator | null>(null);

  // Guessing Game State
  const [gameState, setGameState] = useState<{
    target: Collaborator | null;
    attemptsRemaining: number;
    options: Collaborator[];
    feedback: string | null;
    won: boolean;
    canPlay: boolean;
  }>({
    target: null,
    attemptsRemaining: 2,
    options: [],
    feedback: null,
    won: false,
    canPlay: true
  });

  useEffect(() => {
    localStorage.setItem('album_stats', JSON.stringify(stats));
  }, [stats]);

  useEffect(() => {
    sessionStorage.setItem('isLoggedIn', isLoggedIn.toString());
    sessionStorage.setItem('userEmail', userEmail);
  }, [isLoggedIn, userEmail]);

  const handleLogin = (email: string) => {
    setIsLoggedIn(true);
    setUserEmail(email);
    setShowCover(false);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setUserEmail('');
    setView('album');
  };

  const openPack = () => {
    // Daily Limit Check
    const today = new Date().toISOString().split('T')[0];
    if (stats.lastPackDate === today) {
      alert('Você já resgatou seu pack diário hoje! Volte amanhã.');
      return;
    }

    const newPack: Collaborator[] = [];
    for (let i = 0; i < 3; i++) {
      const rand = Math.random();
      let pool = COLLABORATORS;
      
      // Weighting 
      if (rand > 0.95) {
        pool = COLLABORATORS.filter(c => c.rarity === Rarity.LEGENDARY);
      } else if (rand > 0.8) {
        pool = COLLABORATORS.filter(c => c.rarity === Rarity.RARE);
      } else {
        pool = COLLABORATORS.filter(c => c.rarity === Rarity.COMMON);
      }
      
      if (pool.length === 0) pool = COLLABORATORS; // Fallback
      newPack.push(pool[Math.floor(Math.random() * pool.length)]);
    }
    
    setActivePack(newPack);
    setView('opening');
    
    setStats(prev => {
      const newOwned = [...prev.stickersOwned];
      const newDuplicates = { ...prev.duplicates };
      
      newPack.forEach(c => {
        if (newOwned.includes(c.id)) {
          newDuplicates[c.id] = (newDuplicates[c.id] || 0) + 1;
        } else {
          newOwned.push(c.id);
        }
      });

      return {
        ...prev,
        stickersOwned: newOwned,
        duplicates: newDuplicates,
        packetsOpened: prev.packetsOpened + 1,
        lastPackDate: today
      };
    });
  };

  const handleTrade = (_id?: string) => {
    const totalDuplicates: number = Object.values(stats.duplicates).reduce((a, b) => (a as number) + (b as number), 0) as number;
    if (totalDuplicates < 3) return;

    // Pick a card the user DOESN'T have
    const unowned = COLLABORATORS.filter(c => !stats.stickersOwned.includes(c.id));
    if (unowned.length === 0) {
      alert('Você já completou o álbum!');
      return;
    }

    const newCard = unowned[Math.floor(Math.random() * unowned.length)];
    
    setStats(prev => {
      const newDuplicates = { ...prev.duplicates };
      let removedCount = 0;
      
      // Remove 3 duplicates
      for (const id in newDuplicates) {
        while (newDuplicates[id] > 0 && removedCount < 3) {
          newDuplicates[id]--;
          removedCount++;
        }
        if (removedCount >= 3) break;
      }

      return {
        ...prev,
        stickersOwned: [...prev.stickersOwned, newCard.id],
        duplicates: newDuplicates
      };
    });

    setActivePack([newCard]);
    setView('opening');
  };

  const startNewGame = () => {
    // Check daily limit
    const today = new Date().toISOString().split('T')[0];
    if (stats.lastGuessDate === today) {
      setGameState(prev => ({ ...prev, feedback: 'Você já jogou hoje! Volte amanhã para novos desafios.', canPlay: false }));
      setView('game');
      return;
    }

    const target = COLLABORATORS[Math.floor(Math.random() * COLLABORATORS.length)];
    const options = [target];
    while (options.length < 4) {
      const other = COLLABORATORS[Math.floor(Math.random() * COLLABORATORS.length)];
      if (!options.find(o => o.id === other.id)) {
        options.push(other);
      }
    }
    setGameState({
      target,
      attemptsRemaining: 2,
      options: options.sort(() => Math.random() - 0.5),
      feedback: null,
      won: false,
      canPlay: true
    });
    setView('game');
  };

  const submitGuess = (guessId: string) => {
    if (gameState.won || gameState.attemptsRemaining <= 0) return;

    const today = new Date().toISOString().split('T')[0];

    if (guessId === gameState.target?.id) {
      setGameState(prev => ({ ...prev, won: true, feedback: 'Excelente! Você reconheceu o talento!' }));
      setStats(prev => ({ 
        ...prev, 
        guessesRight: prev.guessesRight + 1, 
        guessesTotal: prev.guessesTotal + 1,
        lastGuessDate: today
      }));
    } else {
      const remaining = gameState.attemptsRemaining - 1;
      setGameState(prev => ({ 
        ...prev, 
        attemptsRemaining: remaining,
        feedback: remaining > 0 ? 'Tente novamente! Analise bem os atributos.' : `Infelizmente não... Era ${gameState.target?.name}!`
      }));
      if (remaining === 0) {
        setStats(prev => ({ ...prev, guessesTotal: prev.guessesTotal + 1, lastGuessDate: today }));
      }
    }
  };

  const goToNextPage = () => {
    if (currentPage < TOTAL_PAGES - 1) setCurrentPage(currentPage + 1);
  };

  const goToPrevPage = () => {
    if (currentPage > 0) setCurrentPage(currentPage - 1);
  };

  if (!isLoggedIn) {
    return <AlbumCover onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen vintage-paper text-slate-900 font-sans selection:bg-red-600 selection:text-white border-8 border-red-600">
      {/* Top Navbar */}
      <nav className="sticky top-0 z-50 bg-red-600 border-b-4 border-red-800 shadow-xl px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center border-4 border-red-800 shadow-[0_0_15px_rgba(255,255,255,0.4)]">
            <span className="text-red-600 font-black text-2xl italic">F</span>
          </div>
          <div>
            <h1 className="text-xl font-black tracking-tighter text-white uppercase leading-none">
              Copa do mundo Fanfortes
            </h1>
            <p className="text-[10px] font-black text-red-100 tracking-[0.2em] uppercase mt-1">Álbum de Conquistas & Talentos</p>
          </div>
        </div>

        <div className="hidden lg:flex items-center gap-6">
          <div className="bg-red-800/40 px-4 py-2 rounded-lg border border-red-400/20">
            <p className="text-[10px] text-red-200 uppercase tracking-widest font-black">Coleção</p>
            <p className="text-lg font-black text-white leading-tight">
              {stats.stickersOwned.length} <span className="text-red-300 text-xs font-bold">/ {COLLABORATORS.length}</span>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Auth UI */}
          {isLoggedIn && (
            <div className="flex items-center gap-2">
              <div className="hidden xl:flex flex-col items-end mr-2">
                <span className="text-[8px] font-black text-red-200 uppercase leading-none">Colaborador</span>
                <span className="text-[10px] font-bold text-white leading-none whitespace-nowrap overflow-hidden text-ellipsis max-w-[120px]">
                  {userEmail.split('@')[0]}
                </span>
              </div>
              <button 
                onClick={handleLogout}
                title="Sair"
                className="flex items-center gap-2 bg-red-900/40 hover:bg-red-900 text-red-200 p-2 rounded-lg text-xs font-black transition-all border border-red-700/30"
              >
                <LogOut size={16} />
                <span className="hidden lg:inline uppercase">Sair</span>
              </button>
            </div>
          )}
          
          <div className="h-8 w-px bg-red-400/20 mx-2" />

          <button 
            onClick={() => setShowCover(true)}
            title="Ver Capa"
            className="p-2 rounded-lg transition-all hover:bg-black/10 text-white/70"
          >
            <Bot size={20} />
          </button>

          <button 
            onClick={() => setView('album')}
            title="Ver Álbum"
            className={`p-2 rounded-lg transition-all ${view === 'album' ? 'bg-white text-red-600 shadow-lg scale-110' : 'hover:bg-black/10 text-white/70'}`}
          >
            <Book size={20} />
          </button>
          <button 
            onClick={() => setView('ranking')}
            title="Ver Ranking"
            className={`p-2 rounded-lg transition-all ${view === 'ranking' ? 'bg-white text-red-600 shadow-lg scale-110' : 'hover:bg-black/10 text-white/70'}`}
          >
            <TrendingUp size={20} />
          </button>
          <button 
            onClick={() => setView('trading')}
            title="Trocar Repetidas"
            className={`p-2 rounded-lg transition-all ${view === 'trading' ? 'bg-white text-red-600 shadow-lg scale-110' : 'hover:bg-black/10 text-white/70'}`}
          >
            <ArrowLeftRight size={20} />
          </button>
          <button 
            onClick={startNewGame}
            title="Adivinhar Carta"
            className={`p-2 rounded-lg transition-all ${view === 'game' ? 'bg-white text-red-600 shadow-lg scale-110' : 'hover:bg-black/10 text-white/70'}`}
          >
            <Gamepad2 size={20} />
          </button>
          <button 
            onClick={openPack}
            className="flex items-center gap-2 bg-white hover:bg-red-50 text-red-600 px-4 py-2 rounded-lg text-sm font-black transition-all shadow-lg hover:scale-105 active:scale-95 ml-2 border-2 border-red-700"
          >
            <Package size={18} />
            <span className="hidden sm:inline italic uppercase">PACK</span>
          </button>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto p-8 bg-white min-h-[calc(100vh-100px)]">
        <AnimatePresence mode="wait">
          {view === 'album' && (
            <motion.div 
              key="album"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.02 }}
              className="space-y-12"
            >
              {stats.stickersOwned.length === 0 ? (
                <div className="text-center py-24 bg-slate-50 rounded-[40px] border-4 border-red-100 space-y-8 flex flex-col items-center">
                  <div className="w-24 h-24 bg-red-100 border-2 border-red-200 rounded-3xl flex items-center justify-center rotate-12 mx-auto">
                    <Package className="text-red-500" size={48} />
                  </div>
                  <div className="space-y-3">
                    <h3 className="text-3xl font-black uppercase italic tracking-tighter text-slate-800">Álbum Vazio!</h3>
                    <p className="text-slate-500 max-w-sm mx-auto font-medium">Capture talentos exclusivos e complete sua coleção de raridades da empresa.</p>
                  </div>
                  <button 
                    onClick={openPack}
                    className="bg-red-600 hover:bg-red-500 text-white px-10 py-4 rounded-2xl font-black italic uppercase tracking-widest transition-all shadow-xl shadow-red-600/30 flex items-center gap-3"
                  >
                    Resgatar Primeiro Pack <ChevronRight size={20} />
                  </button>
                </div>
              ) : (
                <div className="space-y-8 pb-12">
                   <div className="flex justify-center max-w-3xl mx-auto relative overflow-visible">
                      <AnimatePresence mode="wait" custom={direction}>
                        <AlbumPage 
                          key={currentPage}
                          pageIndex={currentPage} 
                          ownedStickers={stats.stickersOwned} 
                          onStickerClick={setSelectedSticker} 
                          direction={direction}
                        />
                      </AnimatePresence>
                   </div>
                  
                  {/* Page Controls */}
                  <div className="flex items-center justify-center gap-12 pt-12">
                    <button 
                      onClick={() => paginate(Math.max(0, currentPage - 1))}
                      disabled={currentPage === 0}
                      className="p-4 rounded-full bg-slate-100 hover:bg-slate-200 disabled:opacity-30 disabled:cursor-not-allowed transition-all shadow-sm group"
                    >
                      <ChevronLeft size={32} className="text-red-600 group-hover:-translate-x-1 transition-transform" />
                    </button>
                    
                    <div className="flex gap-3">
                      {Array.from({ length: TOTAL_PAGES }).map((_, i) => (
                        <button
                          key={i}
                          onClick={() => paginate(i)}
                          className={`w-3 h-3 rounded-full transition-all ${currentPage === i ? 'bg-red-600 scale-125 shadow-lg' : 'bg-slate-200 hover:bg-slate-300'}`}
                        />
                      ))}
                    </div>

                    <button 
                      onClick={() => paginate(Math.min(TOTAL_PAGES - 1, currentPage + 1))}
                      disabled={currentPage === TOTAL_PAGES - 1}
                      className="p-4 rounded-full bg-slate-100 hover:bg-slate-200 disabled:opacity-30 disabled:cursor-not-allowed transition-all shadow-sm group"
                    >
                      <ChevronRight size={32} className="text-red-600 group-hover:translate-x-1 transition-transform" />
                    </button>
                  </div>
                </div>
              )}
            </motion.div>
          )}

          {view === 'ranking' && <RankingSection currentOwned={stats.stickersOwned.length} />}
          
          {view === 'trading' && <TradingSection stats={stats} onTrade={handleTrade} />}

          {view === 'game' && (
            <motion.div 
              key="game"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="max-w-4xl mx-auto space-y-12 py-8"
            >
              <div className="bg-red-50 border-4 border-red-100 rounded-[40px] p-8 md:p-12 flex flex-col items-center text-center shadow-lg relative overflow-hidden">
                <div className="absolute top-0 right-0 w-64 h-64 bg-red-200/20 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl pointer-events-none" />
                
                <div className="w-20 h-20 bg-red-600 rounded-2xl rotate-12 flex items-center justify-center shadow-2xl border-4 border-red-400 mb-8 mx-auto">
                  <Search className="text-white" size={36} />
                </div>
                
                <h2 className="text-4xl md:text-5xl font-black uppercase italic text-red-600 mb-4 tracking-tighter">Quem é este Player?</h2>
                <p className="text-slate-500 font-medium mb-12">Desvende a identidade através dos atributos de combate.</p>

                {!gameState.canPlay && gameState.feedback ? (
                  <div className="space-y-6">
                    <p className="p-8 bg-white border-2 border-red-100 rounded-3xl text-red-600 font-black uppercase italic">
                      {gameState.feedback}
                    </p>
                    <button onClick={() => setView('album')} className="text-slate-400 hover:text-red-600 font-black uppercase italic tracking-widest text-xs transition-colors">
                      Voltar ao Álbum
                    </button>
                  </div>
                ) : gameState.target && (
                  <div className="w-full flex flex-col md:flex-row gap-12 items-start text-left">
                    {/* Character Card / Hidden Image */}
                    <div className="w-full md:w-1/2 flex justify-center">
                      <div className="w-full max-w-[280px] aspect-[3/4] p-4 rounded-3xl bg-white border-4 border-red-200 shadow-2xl relative overflow-hidden group">
                        {gameState.won ? (
                          <motion.img 
                            initial={{ scale: 1.5, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            src={gameState.target.imageUrl} 
                            className="w-full h-full object-cover rounded-2xl" 
                            referrerPolicy="no-referrer"
                          />
                        ) : (
                          <div className="h-full w-full bg-slate-50 flex flex-col items-center justify-center gap-6 rounded-2xl border border-slate-100">
                            <div className="relative">
                              <Search size={64} className="text-red-200 animate-pulse" />
                            </div>
                            <span className="text-[10px] uppercase tracking-[0.4em] font-black text-red-300">Analisando...</span>
                          </div>
                        )}
                        <div className="absolute bottom-6 left-6 right-6 p-3 bg-red-600/90 backdrop-blur-md rounded-xl border border-red-400 text-center">
                           <span className="text-[10px] font-black text-white uppercase italic">Power: {Math.round((gameState.target.attributes.agility + gameState.target.attributes.defense + gameState.target.attributes.attack)/3)}</span>
                        </div>
                      </div>
                    </div>

                    {/* Stats & Guessing */}
                    <div className="flex-1 w-full space-y-8">
                       <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full">
                        <div className="bg-white p-4 rounded-2xl border border-red-100 text-left shadow-sm">
                          <p className="text-red-500 font-black text-[10px] mb-2 uppercase tracking-widest">⌨️ AGILIDADE</p>
                          <StatBar 
                            label="" 
                            value={gameState.target.attributes.agility} 
                            icon={Zap} 
                            color="text-red-500" 
                            description="Velocidade na entrega de soluções e resposta a incidentes críticos."
                          />
                        </div>
                        <div className="bg-white p-4 rounded-2xl border border-blue-100 text-left shadow-sm">
                          <p className="text-blue-500 font-black text-[10px] mb-2 uppercase tracking-widest">🛡️ DEFESA BUGS</p>
                          <StatBar 
                            label="" 
                            value={gameState.target.attributes.defense} 
                            icon={Shield} 
                            color="text-blue-500" 
                            description="Capacidade de criar sistemas resilientes e blindados contra falhas."
                          />
                        </div>
                        <div className="bg-white p-4 rounded-2xl border border-orange-100 text-left shadow-sm">
                          <p className="text-orange-500 font-black text-[10px] mb-2 uppercase tracking-widest">⚔️ CRIATIVIDADE</p>
                          <StatBar 
                            label="" 
                            value={gameState.target.attributes.attack} 
                            icon={Sword} 
                            color="text-orange-500" 
                            description="Poder de inovação e criação de novas features disruptivas."
                          />
                        </div>
                        <div className="bg-white p-4 rounded-2xl border border-red-100 text-left shadow-sm">
                          <p className="text-red-400 font-black text-[10px] mb-1 uppercase tracking-widest">✨ RARIDADE</p>
                          <p className="text-red-600 font-black italic text-xl uppercase tracking-tighter">{gameState.target.rarity}</p>
                        </div>
                      </div>

                      <div className="space-y-4">
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Memória do Log</p>
                        <p className="text-xl italic text-slate-600 font-serif leading-relaxed font-light border-l-4 border-red-600 pl-6">
                          "{gameState.target.bio}"
                        </p>
                      </div>

                      <div className="pt-8 space-y-6">
                        <div className="grid grid-cols-2 gap-4">
                          {gameState.options.map(option => (
                            <button
                              key={option.id}
                              disabled={gameState.won || gameState.attemptsRemaining === 0}
                              onClick={() => submitGuess(option.id)}
                              className={`p-4 rounded-2xl font-black italic uppercase transition-all text-left flex items-center justify-between group text-sm ${
                                gameState.won && option.id === gameState.target?.id 
                                  ? 'bg-red-600 text-white translate-x-1 shadow-lg' 
                                  : 'bg-white hover:bg-red-50 text-slate-500 border border-red-100 hover:border-red-400'
                              } disabled:opacity-50`}
                            >
                              {option.name}
                              <ChevronRight size={18} className={`${gameState.won && option.id === gameState.target?.id ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'} transition-opacity`} />
                            </button>
                          ))}
                        </div>

                        {gameState.feedback && (
                          <motion.div 
                            initial={{ opacity: 0, scale: 0.9 }}
                            animate={{ opacity: 1, scale: 1 }}
                            className={`p-5 rounded-2xl text-center font-black italic uppercase text-xs border-2 tracking-widest ${
                              gameState.won ? 'bg-emerald-600 border-emerald-700 text-white shadow-lg' : 'bg-red-50 border-red-100 text-red-600'
                            }`}
                          >
                            {gameState.feedback}
                          </motion.div>
                        )}

                        <div className="flex items-center justify-between pt-6">
                          <div className="flex gap-2">
                            {[...Array(2)].map((_, i) => (
                              <div key={i} className={`w-3 h-3 rounded-full ${i < gameState.attemptsRemaining ? 'bg-red-600 shadow-[0_0_8px_rgba(239,68,68,0.5)]' : 'bg-slate-200'}`} />
                            ))}
                          </div>
                          {(gameState.won || gameState.attemptsRemaining === 0) && (
                            <button 
                              onClick={startNewGame}
                              className="text-red-600 hover:text-red-700 font-black italic uppercase tracking-widest flex items-center gap-2 group text-xs"
                            >
                              Próximo Cartão <ChevronRight size={16} className="group-hover:translate-x-1 transition-transform" />
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          )}

          {view === 'opening' && (
            <motion.div 
              key="opening"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="max-w-6xl mx-auto py-24 text-center"
            >
              <div className="mb-16 space-y-4">
                <div className="w-20 h-20 bg-red-100 border-2 border-red-200 rounded-full flex items-center justify-center mx-auto mb-8 animate-bounce">
                  <Sparkles className="text-red-600" size={40} />
                </div>
                <h2 className="text-6xl font-black italic uppercase tracking-tighter text-red-600">Novo Pack Resgatado!</h2>
                <p className="text-slate-500 font-medium">As entidades de talentos se manifestaram em sua coleção.</p>
              </div>

              <div className="flex flex-wrap justify-center gap-16 px-4">
                {activePack.map((c, i) => (
                  <motion.div
                    key={`${c.id}-${i}`}
                    initial={{ opacity: 0, scale: 0.5, rotateY: 180, y: 50 }}
                    animate={{ 
                      opacity: 1, 
                      scale: 1.1, 
                      rotateY: 0,
                      y: 0,
                      transition: { delay: i * 0.4, type: 'spring', damping: 12, stiffness: 80 }
                    }}
                    className="w-72"
                  >
                    <StickerCard collaborator={c} />
                    <motion.div 
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1, transition: { delay: i * 0.4 + 0.6 } }}
                      className={`mt-8 text-xs font-black italic uppercase tracking-[0.2em] ${stats.stickersOwned.filter(id => id === c.id).length > 1 ? 'text-slate-600' : 'text-emerald-400'}`}
                    >
                      {stats.stickersOwned.filter(id => id === c.id).length > 1 ? 'DUPLICADA' : 'NOVO TALENTO'}
                    </motion.div>
                  </motion.div>
                ))}
              </div>

              <motion.button
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0, transition: { delay: 1.8 } }}
                onClick={() => setView('album')}
                className="mt-24 bg-red-600 hover:bg-red-500 text-white px-12 py-4 rounded-2xl font-black italic uppercase tracking-widest text-sm border-2 border-red-800 transition-all hover:scale-105 active:scale-95 shadow-xl"
              >
                Voltar ao Álbum
              </motion.button>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      <footer className="max-w-7xl mx-auto p-8 border-t border-red-100 text-center mt-auto">
        <p className="text-[10px] font-black font-mono tracking-[0.4em] uppercase text-red-200">System ID: AIS-TECH-2026 // All Employee Rights Reserved // Panini Retro Engine v5.0</p>
      </footer>

      {/* Selected Sticker Modal remains with slight Polish */}
      <AnimatePresence>
        {selectedSticker && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-6 sm:p-12">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedSticker(null)}
              className="absolute inset-0 bg-red-950/40 backdrop-blur-md" 
            />
            
            <div className="relative flex flex-col lg:flex-row items-center gap-16 z-10 w-full max-w-6xl">
              <motion.div
                layoutId={`card-${selectedSticker.id}`}
                className="w-full max-w-[360px] aspect-[3/4]"
              >
                <StickerCard collaborator={selectedSticker} />
              </motion.div>
              
              <motion.div 
                initial={{ opacity: 0, x: 40 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 40 }}
                className="max-w-xl space-y-10"
              >
                <div className="space-y-6">
                  <div className="flex items-center gap-4">
                    <div className={`px-4 py-1.5 rounded-lg text-[10px] font-black uppercase italic tracking-widest ${
                      selectedSticker.rarity === Rarity.LEGENDARY ? 'bg-red-600 text-white' : selectedSticker.rarity === Rarity.RARE ? 'bg-red-500 text-white' : 'bg-slate-700 text-white'
                    }`}>
                      {selectedSticker.rarity}
                    </div>
                    <span className="text-red-400 font-black font-mono text-sm tracking-widest">REF ID #{selectedSticker.id.padStart(3, '0')}</span>
                  </div>
                  <h2 className="text-6xl md:text-7xl font-black italic tracking-tighter leading-none text-slate-900 uppercase">{selectedSticker.name}</h2>
                  <h3 className="text-2xl text-red-600 font-black italic uppercase tracking-tighter">{selectedSticker.role}</h3>
                </div>

                <div className="p-10 bg-white border-4 border-red-100 rounded-[40px] shadow-2xl relative">
                  <div className="absolute -top-5 -left-5 bg-red-600 p-4 rounded-2xl shadow-2xl rotate-12">
                    <Sparkles className="text-white" size={24} />
                  </div>
                  
                  <p className="text-slate-600 leading-relaxed mb-10 font-serif italic text-2xl font-light">
                    "{selectedSticker.bio}"
                  </p>
                  
                  <div className="space-y-6">
                    <h4 className="text-[10px] font-black uppercase tracking-[0.4em] text-red-300">Conquistas Desbloqueadas</h4>
                    <div className="flex flex-wrap gap-3">
                      {selectedSticker.achievements.map((a, i) => (
                        <span key={i} className="px-6 py-3 bg-red-50 rounded-2xl text-xs border border-red-100 text-red-600 font-black italic uppercase tracking-widest">
                          {a}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                <button 
                  onClick={() => setSelectedSticker(null)}
                  className="w-full py-5 bg-red-600 hover:bg-red-700 text-white rounded-3xl font-black italic uppercase tracking-[0.2em] flex items-center justify-center gap-3 transition-all border-2 border-red-800 shadow-2xl"
                >
                  <ChevronLeft size={20} /> 
                  Fechar Visualização
                </button>
              </motion.div>
            </div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
