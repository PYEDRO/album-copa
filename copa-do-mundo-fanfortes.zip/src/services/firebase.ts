import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, signInWithPopup } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

let auth: any;
let db: any;
let initialized = false;

const initializeFirebase = async () => {
  if (initialized) return;
  try {
    // @ts-ignore
    const config = await import(/* @vite-ignore */ '../../firebase-applet-config.json');
    if (config.default && Object.keys(config.default).length > 0) {
      const app = initializeApp(config.default);
      auth = getAuth(app);
      db = getFirestore(app);
    }
  } catch (e) {
    console.warn("Firebase config not found or invalid. Using mock auth.");
  }
  initialized = true;
};

export const googleProvider = new GoogleAuthProvider();

export const signInWithGoogle = async () => {
  await initializeFirebase();
  if (!auth) {
    // Mock login if firebase is not yet configured
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          user: {
            email: 'user@gmail.com',
            displayName: 'Usuário Teste'
          }
        });
      }, 1000);
    });
  }
  return signInWithPopup(auth, googleProvider);
};

export { auth, db };
